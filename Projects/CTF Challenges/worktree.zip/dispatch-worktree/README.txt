Dispatch archival workspace.
Dispatches use Base64 over a repeating-key XOR byte mask from dispatch.ini.
The last commit was amended before this working copy was exported.
